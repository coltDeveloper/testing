
gitclone 


-------------Run Backend--------------

cd backend

npm install

npm run dev

start on localhost 5000 


------------Run Frontend--------------------

cd frontend

npm install

npm start

start on localhost 3000

------------------------------------------------------------

click on link to open the app
https://www.awesomescreenshot.com/video/37389950?key=cbfe632de55dc289954a260fc75e284b          